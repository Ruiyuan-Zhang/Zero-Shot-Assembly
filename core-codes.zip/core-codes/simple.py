import os
import sys
import time
import pandas as pd
import numpy as np
import threading
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from pyntcloud import PyntCloud
import random
from PIL import Image
from tqdm import tqdm
import copy
from diffusers.pipelines.stable_diffusion.pipeline_stable_diffusion import StableDiffusionPipeline 
from guidance.diffusion_point_cloud import DiffusionPointCloud
from data.split_image import preprocess_and_split
from data.compose_image import compose, compose_v2
from data.utils import set_requires_grad, differentiable_resize, save_tensor_image, seed_everything, render_pointcloud_to_image
from losses.loss import compute_loss, compute_eye_loss, compute_ones_loss, compute_only_loss
from models.regressor import SdsStocasticPoseRegressor, SdsSimplePoseRegressor
from guidance.stable_diffusion import StableDiffusion
from pytorch3d.loss import chamfer_distance
from pytorch3d.io import save_ply, load_ply
from pytorch3d.ops import knn_points, iterative_closest_point
from pytorch3d.transforms import Rotate, Translate, random_rotation
from pytorch3d.renderer import FoVOrthographicCameras
from pytorch3d.renderer import FoVPerspectiveCameras
from pytorch3d.renderer import PointsRasterizationSettings
from pytorch3d.transforms import quaternion_to_matrix, matrix_to_quaternion, euler_angles_to_matrix, Transform3d
from scipy.spatial.transform import Rotation as R
from pytorch3d.structures import Pointclouds
def train(
        all_pcs, all_valids, all_quat, all_trans, ids, results = [],
        device = 'cuda:0', noise_level = 15, gen_steps = 200, 
        random_times = 20, thread_id = -1, sample_pcs_num = 1000, 
        visual_path = '', 
        learning_rate = 0.1
        ):
    betas, alphas, alphas_cumprod, sqrt_alphas_cumprod, sqrt_one_minus_alphas_cumprod = calculate_diffusion_schedule(100)
    noise = sqrt_one_minus_alphas_cumprod[noise_level]
    corrected_angle = torch.tensor(torch.pi)
    results[thread_id] = []
    for id in ids:
        pcs = all_pcs[id]
        valids = all_valids[id]
        quat = all_quat[id]
        trans = all_trans[id]
        init_pcs_before = transform_pcs(pcs, valids, quat, trans, device, sample_pcs_num = sample_pcs_num)
        pcs_shape = init_pcs_before.shape
        colors = torch.randn((pcs_shape[0], 1, 3)).to(pcs.device).repeat(1, pcs_shape[1], 1).view(-1, 3)
        colors_2d = torch.randn((pcs_shape[0], 1, 3)).to(pcs.device).repeat(1, pcs_shape[1], 1).view(-1, 3).to(device)
        save_colored_pc(init_pcs_before.view(-1,3), colors, os.path.join(visual_path, f'init_pcs_before_{id:04}'))
        
        pcs = rotate_point_cloud_z(copy.deepcopy(init_pcs_before).view(-1, 3), corrected_angle)
        pcs = normalize_point_clouds(pcs.view(1, -1, 3), 'shape_bbox')
        pcs = pcs * 2.5
        pcs = pcs.view(pcs_shape)
        init_pcs = copy.deepcopy(pcs)
        save_colored_pc(init_pcs.view(-1,3), colors, os.path.join(visual_path, f'init_pcs_{id:04}'))
        init_noisy_pcs = add_random_noise(pcs, noise_level=noise)
        save_colored_pc(init_noisy_pcs.view(-1,3), colors, os.path.join(visual_path, f'init_noisy_pcs_{id:04}'))
        
        min_cd_with_seed = 10.
        min_seed = -1
        min_gen_gt = None
        guidance = DiffusionPointCloud(device=device, seed=0)
        for x in random.sample(range(100), random_times):
            seed_everything(x)
            z = torch.randn([1, guidance.ckpt['args'].latent_dim]).to(device)
            z = guidance.model.flow(z, reverse=True).view(1, -1)
            guidance.eval()
            gen_gt = guidance.model.diffusion.sample(pcs_shape[0] * pcs_shape[1], context=z)
            
            cd, _ = chamfer_distance(normalize_point_clouds(copy.deepcopy(init_pcs).view(1, -1, 3), 'shape_bbox'), normalize_point_clouds(copy.deepcopy(gen_gt).view(1, -1, 3), 'shape_bbox'))
            if cd < min_cd_with_seed:
                min_cd_with_seed = cd
                min_seed = x
                min_gen_gt = copy.deepcopy(gen_gt)
        seed_everything(min_seed)
        z = torch.randn([1, guidance.ckpt['args'].latent_dim]).to(device)
        z = guidance.model.flow(z, reverse=True).view(1, -1)
        guidance.eval()
        noisy_pcs = copy.deepcopy(init_noisy_pcs)
        noisy_pcs = noisy_pcs.view(*pcs_shape)
        
        model = SdsSimplePoseRegressor(768, 2, embed_num=pcs_shape[0]).to(device)
        optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        gen_gt = normalize_point_clouds(copy.deepcopy(min_gen_gt).view(1, -1, 3), 'shape_bbox')
        last_cd, last_pcs = None, None
        for step in tqdm(range(gen_steps)):
            optimizer.zero_grad()
            rot, trans = model()
            pred = model.get_pcs(rot, trans, pcs=noisy_pcs)
            pred_normal = normalize_point_clouds(pred.clone().view(1, -1, 3), 'shape_bbox')
            loss, _ = chamfer_distance(pred_normal.view(1,-1,3), gen_gt.view(1,-1,3))
            loss.backward()
            optimizer.step()
            
            if False:
                with torch.no_grad():
                    save_ply_and_image(pred, device, os.path.join(visual_path, 'pred'), False)
            if step == gen_steps -1:
                last_cd = loss.item()
                last_pcs = pred.detach()
        
        save_colored_pc(last_pcs.view(-1,3), colors, os.path.join(visual_path, f'last_pcs_{id:04}_{min_seed:02}_{last_cd}'))
        results[thread_id].append({
            'last_pcs': last_pcs,
            'last_cd': last_cd,
            'model': model.state_dict(),
        })
def save_ply_and_image(pcs, device, path_name='results/assemlby',_save_ply=False):
    if _save_ply:
        save_ply(f"{path_name}.ply", verts=pcs.view(-1,3))
    image = render_pointcloud_to_image(pcs, device, view='zry', dist=5)
    image = image.permute(2,0,1)
    save_tensor_image(image, f'{path_name}.png')
def save_colored_pc(pc, colors, file):
    if colors.shape[1] == 3:
        colors = np.concatenate([colors, np.ones((colors.shape[0], 1))], axis=1)
    pcd_df = pd.DataFrame(data=np.concatenate([pc.cpu(), colors], axis=1), columns=['x', 'y', 'z', 'red', 'green', 'blue', 'alpha'])
    pcd_cloud = PyntCloud(pcd_df)
    pcd_cloud.to_file(file + '.ply')
def transform_pcs(pcs, valids, quat, trans, device, sample_pcs_num = 1000):
    
    pcs = pcs[valids==1].to(device)
    tmp_pcs = torch.empty((pcs.shape[0], sample_pcs_num, 3)).to(device)
    N = pcs.shape[0]
    for i in range(N):
        x = upsample_point_cloud_with_pytorch3d(pcs[i], num_points=10000, )
        indices = torch.randperm(x.shape[0])[:sample_pcs_num]
        tmp_pcs[i] = x[indices]
        R = quaternion_to_matrix(quat[i]).to(device)
        t = trans[i].to(device)
        tmp_pcs[i] = torch.matmul(tmp_pcs[i], R.T) + t
    return tmp_pcs
def calculate_centroids_A(source: torch.Tensor, target: torch.Tensor, min_threshold: float = 1e-3) -> tuple[torch.Tensor, torch.Tensor, int, bool, torch.Tensor, torch.Tensor]:
    
    distances, indices, _ = knn_points(source.unsqueeze(0), target.unsqueeze(0), K=1, return_nn=False)
    overlap_mask = distances.squeeze(0) < min_threshold  
    overlap_mask = overlap_mask.squeeze(-1)
    num_A_intersection_B = overlap_mask.sum()
    
    overlap_points = source[overlap_mask]
    centroid_overlap = overlap_points.mean(dim=0) if overlap_points.size(0) > 0 else None
    
    only_source = source[~overlap_mask]
    centroid_only_source = only_source.mean(dim=0) if only_source.size(0) > 0 else None
    move_distance = distances.min()     
    
    centroid_source = source.mean(dim=0)
    centroid_target = target.mean(dim=0)
    return centroid_overlap, centroid_only_source, num_A_intersection_B, move_distance, centroid_source, centroid_target 
def calculate_centroids_with_knn(pcs, min_threshold=1e-3, max_threshold=1.):
    num_clouds = pcs.shape[0]
    results = []
    for i in range(num_clouds):
        for j in range(i + 1, num_clouds):
            A = pcs[i]  
            B = pcs[j]  
            
            
            centroid_overlap_A, centroid_only_A, num_A_intersection_B, move_distance, centroid_source, centroid_target = calculate_centroids_A(A, B, min_threshold)
            
            results.append({
                'pair': (i, j),
                'center_A_intersection_B': centroid_overlap_A, 
                'center_A_subtract_B': centroid_only_A,        
                'num_A_intersection_B': num_A_intersection_B,  
                'direction_A': (centroid_only_A - centroid_overlap_A) / torch.norm(centroid_only_A - centroid_overlap_A) if (centroid_only_A is not None and centroid_overlap_A is not None) else None,
                'move_distance': move_distance,
                'direction_A_move_to_B': (centroid_target - centroid_source) / torch.norm(centroid_target - centroid_source),
                'path_A_move_to_B': centroid_target - centroid_source,
                'move_near': move_distance > max_threshold,
                'centroid_source': centroid_source,
                'centroid_target': centroid_target,
            })
    
    return results
def push_apart(pcs, centroids, rate=0.1):
    
    
    overlap = False
    for result in centroids:
        print(f'Pair: {result["pair"]}, 求A与B之间重合部分点的质心: {result["center_A_intersection_B"]};',
            f'在A上减去重叠部分的新质心: {result["center_A_subtract_B"]};',
            f'重合点的数量：{result["num_A_intersection_B"]};',
            f'A的移动方向: {result["direction_A"]};',
            f'靠近距离: {result["move_distance"]}')
        if result["num_A_intersection_B"] > 0:
            overlap = True
            i, j = result["pair"]
            pcs[i] += rate * result["direction_A"]
    
    return pcs, overlap
class UnionFind:
    def __init__(self, size):
        self.parent = [i for i in range(size)]
        self.rank = [1] * size
    def find(self, p):
        
        if self.parent[p] != p:
            self.parent[p] = self.find(self.parent[p])
        return self.parent[p]
    def union(self, p, q):
        rootP = self.find(p)
        rootQ = self.find(q)
        
        if rootP != rootQ:
            
            if self.rank[rootP] > self.rank[rootQ]:
                self.parent[rootQ] = rootP
            elif self.rank[rootP] < self.rank[rootQ]:
                self.parent[rootP] = rootQ
            else:
                self.parent[rootQ] = rootP
                self.rank[rootP] += 1
def push_and_near(pcs, centroids, rate=0.1, min_num_A_intersection_B = 10):
    
    
    overlap = move_near = False  
    uf = UnionFind(pcs.shape[0])
    
    move_near_ij = [[False for i in range(pcs.shape[0])] for j in range(pcs.shape[0])]
    move_ij = [[None for i in range(pcs.shape[0])] for j in range(pcs.shape[0])]
    
    for result in centroids:
                
        i, j = result["pair"]
        if result["num_A_intersection_B"] > min_num_A_intersection_B:
            overlap = True
            pcs[i] += rate * result["direction_A"]
        
        
        if not result['move_near'] or result["num_A_intersection_B"] <= min_num_A_intersection_B:
            uf.union(i, j)  
        if result['move_near']:
            move_near_ij[i][j] = move_near_ij[j][i] = True
            move_ij[i][j], move_ij[j][i] = result["direction_A_move_to_B"], -result["direction_A_move_to_B"]
        else:
            move_near_ij[i][j] = move_near_ij[j][i] = False
            move_ij[i][j] = move_ij[j][i] = (0., 0., 0.)
    
    
    root_summary = {}
    for i in range(pcs.shape[0]):
        root = uf.find(i)
        if root not in root_summary: root_summary[root] = [False for _ in range(pcs.shape[0])]
        root_summary[root][i] = True
    
    if len(root_summary.keys()) > 1:
        move_near = True 
        for key in root_summary.keys():
            
            mask = root_summary[key]
            
            from_center = pcs[mask].mean(dim=0)
            to_center = pcs[~mask].mean(dim=0)
            dir_from_to = (to_center - from_center) / torch.norm(to_center - from_center)
            
            pcs[mask] += rate * dir_from_to
    
    return pcs, overlap, move_near
def push_and_near_gradually(pcs, max_move_num=10, need_min_cd = False, min_cd_with_init=100., rate=0.1, min_num_A_intersection_B=10, max_threshold = 1., min_threshold: float = 1e-3):
    inipcs = copy.deepcopy(pcs)
    last_pcs = copy.deepcopy(pcs)
    
    for i in range(max_move_num):
        
        centroids = calculate_centroids_with_knn(last_pcs, min_threshold = min_threshold, max_threshold = max_threshold)
        tmp_pcs, overlap, move_near = push_and_near(last_pcs, centroids, rate=rate, min_num_A_intersection_B=min_num_A_intersection_B)
        if not overlap and not move_near: break
        if need_min_cd:
            cd, _ = chamfer_distance(inipcs.view(1, -1, 3), tmp_pcs.view(1, -1, 3))
            if cd < min_cd_with_init: 
                return last_pcs
        
        last_pcs = copy.deepcopy(tmp_pcs)
    return last_pcs
def push_apart_gradually(pcs, max_push_num=10, need_min_cd = False, min_cd_with_init=100., rate=0.1):
    inipcs = copy.deepcopy(pcs)
    last_pcs = copy.deepcopy(pcs)
    for i in range(max_push_num):
        print(f'第{i}次移动')
        centroids = calculate_centroids_with_knn(last_pcs)
        pcs, overlap = push_apart(pcs, centroids, rate=rate)
        
        if not overlap: break
        if need_min_cd:
            cd, _ = chamfer_distance(inipcs.view(1, -1, 3), pcs.view(1, -1, 3))
            if cd < min_cd_with_init: 
                return last_pcs
        
        last_pcs = copy.deepcopy(pcs)
    return pcs
def push_apart_fully(pcs, rate=0.1):
    return push_apart_gradually(pcs, max_push_num=sys.maxsize, need_min_cd = False, rate=rate)
def seed_everything(seed: int):
    import random, os
    import numpy as np
    import torch
    
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True    
def get_rigid_transform(point_cloud, forces):
    centroid = point_cloud.mean(dim=0)
    centered_points = point_cloud - centroid
    u, s, vt = torch.svd(centered_points.t())
    principal_direction = u[:, 0] 
    force_direction = forces.mean(dim=0) / forces.norm(dim=1, keepdim=True).mean(dim=0) 
    angle = torch.atan2(force_direction[1], force_direction[0]) - torch.atan2(principal_direction[1], principal_direction[0])
    force_magnitude = forces.norm(dim=1).mean()  
    angle = angle * force_magnitude
    rotation_matrix = torch.tensor([[torch.cos(angle), -torch.sin(angle), 0],
                                     [torch.sin(angle), torch.cos(angle), 0],
                                     [0, 0, 1]]).to(point_cloud.device)
    
    rotated_points = centered_points @ rotation_matrix.t()
    transformed_points = rotated_points + centroid  
    
    return transformed_points, rotation_matrix, centroid
def normalize_point_clouds(pcs, mode):
    
    for i in range(pcs.size(0)):
        pc = pcs[i]
        if mode == 'shape_unit':
            shift = pc.mean(dim=0).reshape(1, 3)
            scale = pc.flatten().std().reshape(1, 1)
        elif mode == 'shape_bbox':
            pc_max, _ = pc.max(dim=0, keepdim=True) 
            pc_min, _ = pc.min(dim=0, keepdim=True) 
            shift = ((pc_min + pc_max) / 2).view(1, 3)
            scale = (pc_max - pc_min).max().reshape(1, 1) / 2
        pc = (pc - shift) / scale
        pcs[i] = pc
    return pcs
def rotate_point_cloud_z(points: torch.Tensor, angle: torch.Tensor) -> torch.Tensor:
    cos_angle = torch.cos(angle)
    sin_angle = torch.sin(angle)
    rotation_matrix = torch.tensor([
        [cos_angle, 0, sin_angle],
        [0,         1, 0],
        [-sin_angle, 0, cos_angle]
    ], dtype=points.dtype, device=points.device)  
    rotated_points = torch.mm(points, rotation_matrix.T)
    return rotated_points
def random_rotation_matrix(rotation_level=1.0):
    euler_angles = np.random.rand(3) * 2 * np.pi
    adjusted_angles = euler_angles * rotation_level
    rotation = R.from_euler('xyz', adjusted_angles)
    return torch.tensor(rotation.as_matrix(), dtype=torch.float32)
def add_random_noise(pcs, noise_level=.5, return_tensor=True):
    noisy_pcs = []
    for i in range(pcs.shape[0]):
        part = pcs[i]
        rotation_matrix = random_rotation_matrix(noise_level).to(pcs.device)
        rotated_part = torch.matmul(part, rotation_matrix)
        translation_vector = torch.randn(3) * noise_level
        translated_part = rotated_part + translation_vector.to(pcs.device)
        noisy_pcs.append(translated_part)
    
    if return_tensor:
        return torch.stack(noisy_pcs)
    else:
        return noisy_pcs
def calculate_diffusion_schedule(num_timesteps):
    
    betas = np.linspace(0.0000, 0.0015, num_timesteps)
    alphas = 1. - betas
    alphas_cumprod = np.cumprod(alphas)
    sqrt_alphas_cumprod = np.sqrt(alphas_cumprod)
    sqrt_one_minus_alphas_cumprod = np.sqrt(1. - alphas_cumprod)
    return betas, alphas, alphas_cumprod, sqrt_alphas_cumprod, sqrt_one_minus_alphas_cumprod
def upsample_point_cloud_with_pytorch3d(point_cloud, num_points=10000, distance_threshold=0.1):
    min_bounds = point_cloud.min(dim=0)[0]  
    max_bounds = point_cloud.max(dim=0)[0]  
    random_points = torch.rand((num_points, 3), device=point_cloud.device) * (max_bounds - min_bounds) + min_bounds
    knn_result = knn_points(random_points.unsqueeze(0), point_cloud.unsqueeze(0), K=1)
    distances = knn_result.dists.squeeze(0).sqrt()  
    
    mask = distances < distance_threshold
    filtered_points = random_points[mask[:,0]]  
    
    return filtered_points
if __name__ == '__main__':
    path = ''
    part_pcs = []
    part_valids = []
    part_quat = []
    part_trans = []
    for i in range(9):
        batch = torch.load(os.path.join(path, f"batch_{i}"))
        part_pcs.append(batch['part_pcs'])
        part_valids.append(batch['part_valids'])
        part_quat.append(batch['part_quat'])
        part_trans.append(batch['part_trans'])
    part_pcs = torch.cat(part_pcs)
    part_valids = torch.cat(part_valids)
    part_quat = torch.cat(part_quat)
    part_trans = torch.cat(part_trans)
    indexes = torch.arange(part_pcs.shape[0])
    ids = indexes.split((len(indexes) + 3) // 4)
    results = [None] * 4
    save_path = ''
    threads = []
    for i in range(4):
        thread = threading.Thread(target=train, kwargs = {
            'all_pcs': part_pcs,
            'all_valids': part_valids,
            'all_quat': part_quat,
            'all_trans': part_trans,
            'ids': ids[i],
            'device': f'cuda:{i//2}',
            'noise_level': 60,
            'thread_id': i,
            'results': results,
            'visual_path': save_path, 
            'learning_rate': 0.1,
        })
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
    torch.save(results, os.path.join(save_path, 'results.pt'))
    torch.save(ids, os.path.join(save_path, 'ids.pt'))
